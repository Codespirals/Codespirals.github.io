self.assetsManifest = {
  "version": "WjrHNWsw",
  "assets": [
    {
      "hash": "sha256-3mm+pmx8dB96Co4Cdo01GbKfbjqvJu/o8GHtKYo0n+A=",
      "url": "404.html"
    },
    {
      "hash": "sha256-wlfQy9GybKKYs+VjhCRj/Gyv3x6ZQFo/YEmy3EI1sFg=",
      "url": "Codespirals.HomePage.styles.css"
    },
    {
      "hash": "sha256-Dg1AKaOQwzOuW/SgwioIs5YmVjSc3m7zW1eKFtZkMJ4=",
      "url": "_framework/Codespirals.Base.Shared.up1hwcggfr.wasm"
    },
    {
      "hash": "sha256-VMpONb2ClhcdG4nbAAcW+jvtVwndT8PGfDAoJ9kbEyE=",
      "url": "_framework/Codespirals.HomePage.kgoevmwjn6.wasm"
    },
    {
      "hash": "sha256-J6VAJzkEP5gc3yegUVeCxRqit6nyh5EitJn+/nAfkrk=",
      "url": "_framework/Codespirals.Solutions.ApiCaller.nwxytqmmng.wasm"
    },
    {
      "hash": "sha256-Dh57L9nxu+ri9x4unzWqtqArq1FNLNpXHLdawKAE0i4=",
      "url": "_framework/Markdig.qqvxzo214f.wasm"
    },
    {
      "hash": "sha256-o9dSmUjbA1PzYKdUQuZTFIzJfDolyjKyChLDq1Ly0Ac=",
      "url": "_framework/Microsoft.AspNetCore.Components.1na6hn0xiy.wasm"
    },
    {
      "hash": "sha256-yZBJ0oe7IESmHZziJwsA5vPnElBJhDOZpxRSjn1NxWQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3dey6fldbd.wasm"
    },
    {
      "hash": "sha256-62QErJpgqCKN27lS+VNff+ELXNdpNauYqgMtE4z2XDo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.pvuft5uwcr.wasm"
    },
    {
      "hash": "sha256-2/DJmNUhlVNQVUEo1pyGSxByNuX7hiAdNOkecoLWSms=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.b01r3smmrg.wasm"
    },
    {
      "hash": "sha256-sAOQZonl6HweeKKBqkGmnA/GU6WJTDrLIqXpyI93kGk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4n3hzdwebh.wasm"
    },
    {
      "hash": "sha256-mch+p+6//RrIAdqEU5hFP0I8YeJDWfddg0wuQ4dI2x0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.jhvk75sg4v.wasm"
    },
    {
      "hash": "sha256-NjAIjIQlITJK5e/1cNjeMLBSuW2yXbc3mfYPnlQU0WU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ixktlrimdt.wasm"
    },
    {
      "hash": "sha256-num2bwPdzWuviaXIa3cKRS5bdzPDyMoEY57FYr5onrQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.mv3nfxtxew.wasm"
    },
    {
      "hash": "sha256-vApiDs9rhWMfSS1dmbWQLO9pMUhX53Xg/1omxYKziNc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.kq4riur6yh.wasm"
    },
    {
      "hash": "sha256-Uf2OoF4AD/nB8bEP9+Vtasx3otZscbwOarFh3Uu7bQI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.b9mcrj62ry.wasm"
    },
    {
      "hash": "sha256-oCBzeuZ9KUwsx6Dfs5uiDkIhTpuRTPYMt/e4hkyW+qg=",
      "url": "_framework/Microsoft.Extensions.Logging.0kdg0ivsu6.wasm"
    },
    {
      "hash": "sha256-3UiRNl+1YdUI4UY9Wtrc4KC+TCCA7VYrAmtbDKb8Y+A=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.9xj8exgt7k.wasm"
    },
    {
      "hash": "sha256-ZIozjKju5LDdurm2Gon6Zm7yhI4iH8Z6eF5lHdwnydo=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.k6n9wij74b.wasm"
    },
    {
      "hash": "sha256-p7hHofH5jRcxcKQ9a002BuiwgWDH4T7k+mQ34NZg7Hk=",
      "url": "_framework/Microsoft.Extensions.Options.b76x71pmkb.wasm"
    },
    {
      "hash": "sha256-ymLJ18O0TWi69zlDhVo+NpMt34Z3v1+9qEyGdf3sJFI=",
      "url": "_framework/Microsoft.Extensions.Primitives.yxjt7vtatl.wasm"
    },
    {
      "hash": "sha256-Xcxd+z/8v1MjYI/6IsNgJ46ifV38aKmiGyz4RR+L0ms=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.5ydn64ly88.wasm"
    },
    {
      "hash": "sha256-bhm2ukyDghndCFOzqpXWj3O52p1Y/wu5bVpMoNjiJXI=",
      "url": "_framework/Microsoft.JSInterop.mnwds181lv.wasm"
    },
    {
      "hash": "sha256-y7NnWh8z8gPuKAQI4hhBL69y2e7NlYbHZDvyDbFBTHI=",
      "url": "_framework/System.1h5i8a3bq8.wasm"
    },
    {
      "hash": "sha256-gvrDkBVeD9qeBt3cbbBTvlL8n+xxoYaEZ9zlITgb9IA=",
      "url": "_framework/System.Collections.Concurrent.i7nwgirehj.wasm"
    },
    {
      "hash": "sha256-MXrcsQ1Ou4n5E+3B3zFuq+8deLKMjTLAYTClr71QCLU=",
      "url": "_framework/System.Collections.Immutable.z77hn01vh8.wasm"
    },
    {
      "hash": "sha256-UIX6/xHVOMi6OqxFTCquGP/BX5iF6ak27hxg0lrS1kI=",
      "url": "_framework/System.Collections.NonGeneric.c921h28lw6.wasm"
    },
    {
      "hash": "sha256-UiMZgRAyY2kTqMgDhhdBWOWY//dvjZMazfjcAzB57rU=",
      "url": "_framework/System.Collections.Specialized.q2nuv1fpsf.wasm"
    },
    {
      "hash": "sha256-hEv/h8PoXFp8CfRLR+DQbemVq84thbYkoUi33FE/sbM=",
      "url": "_framework/System.Collections.syymljxar8.wasm"
    },
    {
      "hash": "sha256-f/FhpzTincxlkk3wddOwOgidwplwYSlbJvSL5a5sos4=",
      "url": "_framework/System.ComponentModel.Primitives.76q4ofqx22.wasm"
    },
    {
      "hash": "sha256-6XQFkurmDd/uQfrmYbqud0SU73j3U75oAE73kn1YV1I=",
      "url": "_framework/System.ComponentModel.TypeConverter.rbvqqwhupx.wasm"
    },
    {
      "hash": "sha256-gROd1mGPH8FaEgzh0nUJBEL8MD/doQc5GIW6YJYD3W4=",
      "url": "_framework/System.ComponentModel.tpqldnnl29.wasm"
    },
    {
      "hash": "sha256-VXvLzEvQYjm6/12GFDjsbvqma50SNnhOx0oSRmE6M+k=",
      "url": "_framework/System.Console.v7hy5xnp6a.wasm"
    },
    {
      "hash": "sha256-hGEG5z/RpOcjnpj2yyK/w8RL4tc1K/KFHa5iPKq+QBg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.gpjrhhbi40.wasm"
    },
    {
      "hash": "sha256-uklIeyr38pTGiOI4XRUhTpvWyS7b5XCaav1yVlq8YeU=",
      "url": "_framework/System.IO.Pipelines.qz0hrnqp31.wasm"
    },
    {
      "hash": "sha256-z1aHmeBps/zlPONaVaVMxbnjL1pcx1V4hjMu5NEz1o8=",
      "url": "_framework/System.Linq.Expressions.xcy1t2wzi5.wasm"
    },
    {
      "hash": "sha256-weq8kiMkNHIuSTWwjNS/1XGHpXuE+UXBm+hZ4sWHxNU=",
      "url": "_framework/System.Linq.xsjqonj8qp.wasm"
    },
    {
      "hash": "sha256-k5oBrRF+vMI3d0bq5j3UKTiRwfdT3IsawK1+/nPDXiw=",
      "url": "_framework/System.Memory.bikruznpie.wasm"
    },
    {
      "hash": "sha256-aLtWkRPm08Xi6gUN9PzhZ3hogeEKg91PHQVhbw3K0iY=",
      "url": "_framework/System.Net.Http.Json.crwr2h0lis.wasm"
    },
    {
      "hash": "sha256-I039/RxcIjEFGMHoE2x3kOiKaDEdz8yCqdkNPL6PI6A=",
      "url": "_framework/System.Net.Http.vh26vrzc9b.wasm"
    },
    {
      "hash": "sha256-1iNEqRJBNK3fkPjdhYlJmj4LxDczGNzFzDEP0km71qY=",
      "url": "_framework/System.Net.Primitives.mphe71cz89.wasm"
    },
    {
      "hash": "sha256-Wr7uYK5IAEEBz//fnLFv8YNhN9O4z269rzOcImH8Yqk=",
      "url": "_framework/System.ObjectModel.2ue58bdwtg.wasm"
    },
    {
      "hash": "sha256-234aAGmxfY3Wgro7RDcmHWmw4ebFoXxsbw/HdaO3CSI=",
      "url": "_framework/System.Private.CoreLib.t6j0g0t18s.wasm"
    },
    {
      "hash": "sha256-vqEyk0jKeazTTAPFgQta5EdFT6sYaKiND7oZ+mt/cx4=",
      "url": "_framework/System.Private.Uri.ay39206pda.wasm"
    },
    {
      "hash": "sha256-lf8bNUBMbJYeAqYxKK6pKywcrKELO2tVs32xlLoJd/M=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.l4nao9l17b.wasm"
    },
    {
      "hash": "sha256-x//xU3DJi0E2+wKgW33NmbmW27iQNlteF/foR9IR6RY=",
      "url": "_framework/System.Runtime.InteropServices.ng7gmszazu.wasm"
    },
    {
      "hash": "sha256-RIV6tqNkt1U7YM+1EqwhrM56yTSjceXUwKzHDJQyj/E=",
      "url": "_framework/System.Runtime.Serialization.Primitives.05x21cay4c.wasm"
    },
    {
      "hash": "sha256-Q4V/szHtebctqYWQNjQwZ4IMbRJGCKKZw3AhmE0cG4Y=",
      "url": "_framework/System.Runtime.j4asvt1p5l.wasm"
    },
    {
      "hash": "sha256-9oHjLDAHVcIqywd/PNY5orqmLFtxqM3BXwnhHntnvjQ=",
      "url": "_framework/System.Security.Cryptography.2lkfgnu7ed.wasm"
    },
    {
      "hash": "sha256-KYBLCEue9CmKDj22l5X4bngHIIpqXx/9ahcmk8vlNkM=",
      "url": "_framework/System.Text.Encodings.Web.n4z4xte3l3.wasm"
    },
    {
      "hash": "sha256-7dxBGA+pJ9IC3RM9Qgv1BgK35DXVnpzX1xlenMxwsqk=",
      "url": "_framework/System.Text.Json.x3afgv92nm.wasm"
    },
    {
      "hash": "sha256-MuHBa8hn7PmQ0UzCfvElSZDURBDZZ1eIGtTkqalE7qs=",
      "url": "_framework/System.Text.RegularExpressions.6q6n9xt0j0.wasm"
    },
    {
      "hash": "sha256-Krwkp7ALo94Ce4zfsZBwTx2Ejv4SJyDRTwJPpvWsVLY=",
      "url": "_framework/System.Threading.q8v88l37pm.wasm"
    },
    {
      "hash": "sha256-yyLzLjbrWnKg4d+0q2hNVMWWwAiqiREg8tGxlWpBSf0=",
      "url": "_framework/System.Web.HttpUtility.duvs52axum.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-hYigRhIZKHyCXxXWqL/yR3ZWzZhV2oSi+2N3/UPeoxk=",
      "url": "_framework/dotnet.native.nxw7lo0lh5.wasm"
    },
    {
      "hash": "sha256-RezASHv+dbqV50cFnld76YiLhk4B+BjMAKs/euUdNyE=",
      "url": "_framework/dotnet.native.vzj2a6aakt.js"
    },
    {
      "hash": "sha256-MZMguyke9CroSQl+L/SHIGFkPTD+LtYGXkXjAvwWx40=",
      "url": "_framework/dotnet.runtime.zbexyp8zrs.js"
    },
    {
      "hash": "sha256-lCf8K30BKvOOFxBQQkvnfwMLSMtvecfVn0ODfyARnII=",
      "url": "_framework/dotnet.scq8h0bxe0.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-3u8mMT9MuVTX5RpiC+pY0WTrADZnJIOa0a98E8GJnmw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-Crdk9030r1ON1PuT7Encq4sCSsGw2LVoMn4y9EfgrY4=",
      "url": "images/icons/icon-64x64.png"
    },
    {
      "hash": "sha256-lDEwO1wDiBNjPkM+dvS6JbDGo1JBTXivNpbh7MXzbI4=",
      "url": "images/icons/icon.png"
    },
    {
      "hash": "sha256-NdmcaUct4QSv3kqrZQh7gbxLRfp4Pm6DyM8R+928DUo=",
      "url": "images/icons/logo.png"
    },
    {
      "hash": "sha256-1qJQGAqjg6Xh2wZ/FwLQ7zITFlI0cdWKlyNjMgG+tbc=",
      "url": "index.html"
    },
    {
      "hash": "sha256-qCDNNbiPqqj4crz1MvFapgy5areakSh9QvhmItp3944=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-yOxDOZLlGfcuatuynf4jAGSSPrAzipdxE5Pfee7LI9k=",
      "url": "posts/HelloWorld.md"
    },
    {
      "hash": "sha256-twSR96YD4pTykuRDS7jL8hOvp8KCasMEO7HCy1YrvHU=",
      "url": "posts/metadata.json"
    },
    {
      "hash": "sha256-RS5TJiU3b4beqTt2/4HBjgBzx6mfzSitpVENm8/GakI=",
      "url": "resources/navlinks.json"
    }
  ]
};
